#include <boost/json.hpp>

#include <iostream>

int main() {
    boost::json::object input;
    input["answer"] = 42;
    input["label"] = "Boost.JSON consumer";
    const auto serialized = boost::json::serialize(input);
    const auto parsed = boost::json::parse(serialized);
    if (!parsed.is_object() || parsed.as_object() != input) {
        std::cerr << "JSON round-trip failed\n";
        return 1;
    }
    std::cout << serialized << '\n';
    return 0;
}
