// Exercise Boost.Exception's compiled extension where it is supported.
#if defined(_MSC_VER)
#define BOOST_ENABLE_NON_INTRUSIVE_EXCEPTION_PTR
#endif
#include <boost/exception_ptr.hpp>

#include <iostream>
#include <stdexcept>
#include <string>

// Boost::test_exec_monitor is always static, including in shared Boost packages.
int test_main(int, char*[]) {
    boost::exception_ptr saved;
    try {
        throw std::runtime_error("static components");
    } catch (...) {
        saved = boost::current_exception();
    }
    if (!saved) {
        return 1;
    }
    try {
        boost::rethrow_exception(saved);
    } catch (const std::runtime_error& error) {
        if (std::string(error.what()) != "static components") {
            return 2;
        }
        std::cout << "Static components linked and executed\n";
        return 0;
    } catch (...) {
        return 3;
    }
    return 4;
}
