# Boost-only clang-cl overlay

This profile overlays a normal MSVC host profile while selecting clang-cl only for Boost.
It does not modify the existing personal windows or windows-clang profiles. A wrapper
passes boost/*:compiler.runtime_type=Debug/Release explicitly, rather than relying on
Jinja seeing later command-line settings or changing a global profile plugin.

scripts/scoped_profile_probes.py tests an MSVC CMake consumer against the already-built
clang-cl Boost 1.89 binaries in Debug/Release and shared/static. --build=never ensures
that a mismatched profile cannot silently trigger new Boost builds. Validated in all four cases. Actual CMake compiler identity is MSVC and actual Boost settings identify clang.
