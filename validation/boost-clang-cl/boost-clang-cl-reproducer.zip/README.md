# Boost clang-cl recipe validation

This archive contains the profiles, CMake consumers and scripts used to check two independent Boost recipe corrections: Windows library naming/packaging, and Microsoft CRT selection with clang-cl. The patch files affect only recipes/boost/all/conanfile.py.

The main build matrix used Conan 2.22.2. There are 24 main configurations and additional checks on Boost 1.78 and 1.85. Runtime cases cover Boost 1.78 and 1.91. A separate MSYS2 UCRT64 GCC check passed with both corrections. CLANG64 retains an earlier GNU-driver selection failure with the unmodified and patched recipes. Conan 2.34.0 also consumed a previously qualified binary with dependency rebuilding disabled. The result tables distinguish these groups.

## Windows reproduction

Extract this archive into a new working directory. Keep its directory structure. Install/provide Conan 2.22.2, clang-cl 20.1.2, CMake, Ninja and VS 2022 C++ tools. The scripts discover VS 2022 through vswhere; there are no user-specific tool paths in the profiles.

From that directory in PowerShell:

```powershell
git clone --filter=blob:none --sparse https://github.com/conan-io/conan-center-index.git cci
git -C cci sparse-checkout set recipes/boost docs .github
git -C cci checkout db8236fe4e9018dbd1b72ff970def9708e8907d4
git -C cci apply ../patches/naming.patch
$env:CONAN_HOME = Join-Path $PWD '.conan-home/windows'
conan download 'b2/5.5.3#043a75bcbb090e3f81f7ac849850d0ca:522dcea5982a3f8a5b624c16477e47195da2f84f#5eb4601bedf23d3a436aa89bfd3e251f' -r conancenter
New-Item -ItemType Directory -Path ./artifacts -Force | Out-Null
conan cache save 'b2/5.5.3#043a75bcbb090e3f81f7ac849850d0ca:522dcea5982a3f8a5b624c16477e47195da2f84f#5eb4601bedf23d3a436aa89bfd3e251f' --file=./artifacts/seed-b2-windows.tgz
$vs = & ./scripts/Initialize-VS2022.ps1
$env:BOOST_RECIPE_VS2022 = $vs.InstallationPath
python -u -B scripts/validate.py --case clang-cl-1.89.0-debug-shared-system-minimal
python -u -B scripts/legacy_probes.py
python -u -B scripts/runtime_probes.py --patched
python -u -B scripts/legacy_runtime_probes.py
python -u -B scripts/runtime_only_probe.py
```

scripts/runtime_only_probe.py checks the runtime correction independently, fetching its exact published commit if necessary. The archived followups/runtime/recipe source copy includes both corrections. The normal cci checkout above contains the naming correction alone, so each script uses the intended recipe. Run configurations sequentially; builds are limited to four jobs. Only Boost may be rebuilt. The b2 tool must already be available in the dedicated cache. Source archives are downloaded and checked by Conan when needed.

The complete matrix can be selected with scripts/validate.py --all. The Linux runner scripts/run-linux.py prepares its own tools and cache. MSYS2 scripts/setup_msys2_validation.py creates a portable root in this working directory; it does not update an existing MSYS2 installation. Its package repositories are rolling, so the actual tested compiler versions are recorded in the result report.

No prebuilt Boost binary is included. These are selected-component validation profiles, not a build of every Boost module.
