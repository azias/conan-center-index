"""Separate Windows CRT probes; do not mix this follow-up into the naming PR."""
import argparse
import json
import pathlib
import shutil
import sys

import validate as driver

parser = argparse.ArgumentParser()
parser.add_argument("--patched", action="store_true")
args = parser.parse_args()
if driver.SYSTEM != "windows":
    raise SystemExit("These probes target the Microsoft CRT on Windows.")
if args.patched:
    driver.RECIPE = driver.ROOT / "followups/runtime/recipe"
    if not (driver.RECIPE / "conanfile.py").exists():
        raise SystemExit("Prepare the separate runtime follow-up recipe first.")

original_profile_args = driver.profile_args

def profile_args(case):
    return original_profile_args(case) + [
        "-s:h", "compiler.runtime=" + case["runtime"],
        "-s:h", "compiler.runtime_type=" + case["runtime_type"]]

driver.profile_args = profile_args

def audit(case, package, directory):
    dumpbin = shutil.which("dumpbin.exe", path=driver.ENV["PATH"])
    exception = next((package / "lib").glob("libboost_exception*.lib"))
    log = driver.run([dumpbin, "/nologo", "/directives", exception],
                     directory, "requested-crt-directives")
    text = log.read_text(errors="replace").lower()
    debug = case["runtime_type"] == "Debug"
    base = "libcmt" if case["runtime"] == "static" else "msvcrt"
    expected = base + ("d" if debug else "") + ".lib"
    if expected not in text:
        raise RuntimeError("Requested CRT " + expected + " is absent from the Boost archive.")
    dlls = list((package / "bin").glob("*boost_json*.dll"))
    if case["shared"]:
        log = driver.run([dumpbin, "/nologo", "/dependents", dlls[0]],
                         directory, "requested-crt-dll")
        text = log.read_text(errors="replace").lower()
        expected = "ucrtbased.dll" if debug else "ucrtbase.dll"
        if expected not in text and not (not debug and "api-ms-win-crt" in text):
            raise RuntimeError("Requested CRT " + expected + " is absent from the Boost DLL.")
    return {"runtime": case["runtime"], "runtime_type": case["runtime_type"],
            "archive_defaultlib": base + ("d" if debug else "") + ".lib",
            "dll_runtime": ("ucrtbased.dll" if debug else "ucrtbase.dll") if case["shared"] else None,
            "dlls": [p.name for p in dlls]}

driver.audit_windows = audit
suffix = "fixed" if args.patched else "original"
cases = [
    {"id": "probe-runtime-" + suffix + "-debug-shared-release-crt",
     "compiler": "clang-cl", "version": "1.91.0", "configuration": "Debug",
     "shared": True, "layout": "system", "selection": "minimal",
     "runtime": "dynamic", "runtime_type": "Release"},
    {"id": "probe-runtime-" + suffix + "-release-static-static-crt",
     "compiler": "clang-cl", "version": "1.91.0", "configuration": "Release",
     "shared": False, "layout": "system", "selection": "minimal",
     "runtime": "static", "runtime_type": "Release"}
]
success = True
for case in cases:
    passed = driver.validate(case)
    record = json.loads((driver.ROOT / "validation/results" / (case["id"] + ".json")).read_text())
    if args.patched:
        success = success and passed
    else:
        reproduced = not passed and "Requested CRT " in record.get("error", "")
        print("INDEPENDENT RUNTIME DEFECT REPRODUCED", case["id"], reproduced, flush=True)
        success = success and reproduced
if args.patched and success:
    invalid = {**cases[1], "id": "probe-runtime-fixed-invalid-shared-mt", "shared": True}
    directory = driver.ROOT / "out" / invalid["id"]
    graph = directory / "graph.json"
    try:
        driver.run([driver.CONAN, "graph", "info", "--requires=" + driver.export("1.91.0"),
                    *driver.profile_args(invalid), "--build=never", "--no-remote",
                    "--format=json", "--out-file=" + str(graph)], directory, "invalid-graph")
    except RuntimeError:
        pass
    evidence = (directory / "invalid-graph.log").read_text(errors="replace")
    if graph.exists():
        evidence += graph.read_text(errors="replace")
    rejected = "Boost can not be built as shared library with MT runtime." in evidence
    (driver.ROOT / "validation/runtime-invalid-shared-mt.json").write_text(
        json.dumps({"status": "rejected-as-expected" if rejected else "failed",
                    "compiled": False, "log": "out/probe-runtime-fixed-invalid-shared-mt/invalid-graph.log"}, indent=2) + "\n")
    print("Shared/static-CRT validation", rejected, flush=True)
    success = success and rejected
sys.exit(0 if success else 1)
