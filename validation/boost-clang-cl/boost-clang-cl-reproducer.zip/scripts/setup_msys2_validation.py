"""Prepare a disposable MSYS2 root; never update the user's existing installation."""
import pathlib,subprocess,json,os,urllib.request,hashlib,datetime
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=ROOT/'out/msys2-bootstrap'; OUT.mkdir(parents=True,exist_ok=True)
DEST=ROOT/'.tools/msys2-validation'; DEST.mkdir(parents=True,exist_ok=True)
release=json.loads(subprocess.check_output(['gh','api','repos/msys2/msys2-installer/releases/tags/2026-09-27'],text=True,encoding='utf-8'))
asset=next(a for a in release['assets'] if a['name']=='msys2-base-x86_64-20260927.tar.xz')
sha_asset=next(a for a in release['assets'] if a['name']==asset['name']+'.sha256')
archive=ROOT/'artifacts'/asset['name']
expected=urllib.request.urlopen(sha_asset['browser_download_url']).read().decode().split()[0]
if not archive.exists():
 print('DOWNLOAD',asset['browser_download_url'],flush=True); urllib.request.urlretrieve(asset['browser_download_url'],archive)
actual=hashlib.sha256(archive.read_bytes()).hexdigest(); assert actual==expected
msys=DEST/'msys64'
if not (msys/'usr/bin/bash.exe').exists():
 print('EXTRACT',archive.name,flush=True); subprocess.run(['tar','-xf',str(archive),'-C',str(DEST)],check=True)
env=os.environ.copy(); env['PATH']=str(msys/'usr/bin')+os.pathsep+str(pathlib.Path(os.environ['SYSTEMROOT'])/'System32'); env['MSYSTEM']='MSYS'; env['MSYS2_PATH_TYPE']='minimal'; env['CHERE_INVOKING']='1'
bash=msys/'usr/bin/bash.exe'
def run(command,label):
 args=[str(bash),'--login','-c',command]
 with (OUT/'commands.jsonl').open('a',encoding='utf-8') as f: f.write(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':args,'cwd':str(ROOT)})+'\n')
 print('START',label,flush=True)
 with (OUT/(label+'.log')).open('w',encoding='utf-8') as f: r=subprocess.run(args,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
 print('END',label,r.returncode,flush=True)
 if r.returncode: print((OUT/(label+'.log')).read_text(errors='replace')[-4000:],flush=True)
 return r.returncode
# MSYS2 requires a fresh process after updating the runtime.
first=run('pacman -Syu --noconfirm','update-1')
second=run('pacman -Syu --noconfirm','update-2')
if second: raise SystemExit(second)
packages=['mingw-w64-clang-x86_64-clang','mingw-w64-clang-x86_64-lld','mingw-w64-clang-x86_64-llvm','mingw-w64-ucrt-x86_64-gcc']
rc=run('pacman -S --needed --noconfirm '+' '.join(packages),'install-compilers')
if rc: raise SystemExit(rc)
rc=run("pacman -Q",'installed-packages')
record={'release':release['tag_name'],'url':asset['browser_download_url'],'sha256':actual,'requested_packages':packages,'existing_installation_modified':False,'status':'ready' if rc==0 else 'failed'}
(ROOT/'validation/additional/msys2-bootstrap.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
