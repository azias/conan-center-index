"""Check official and patched Boost with current b2 in a separate Windows cache."""
import json
import os
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
os.environ["BOOST_RECIPE_CACHE"] = str(ROOT / ".conan-home/windows-b2-current")
import validate as driver

if driver.SYSTEM != "windows":
    raise SystemExit("This smoke test targets clang-cl on Windows.")
tool = json.loads((ROOT / "validation/current-b2.json").read_text())
directory = ROOT / "out/current-b2-official-baseline"
driver.run([driver.CONAN, "download", tool["reference"], "-r", "conancenter"],
           directory, "download-current-b2")
reference = "boost/1.89.0#cbbb504bd34923406941724337662b16"
driver.run([driver.CONAN, "download", reference, "--only-recipe", "-r", "conancenter"],
           directory, "download-official")
case = {"id": "current-b2-official-baseline", "compiler": "clang-cl",
        "version": "1.89.0", "configuration": "Debug", "shared": True,
        "layout": "system", "selection": "minimal"}
try:
    driver.run([driver.CONAN, "install", "--requires=" + reference,
                *driver.profile_args(case), "--build=missing:boost/*", "--no-remote",
                "-of", directory / "generators"], directory, "install-official")
except RuntimeError:
    text = (directory / "install-official.log").read_text(errors="replace")
    if not ("package_info()" in text and "boost_json" in text and "b2/5.6.1" in text):
        raise
    record = {"status": "reproduced", "qualified": False, "reference": reference,
              "b2_reference": tool["reference"], "stage": "package_info",
              "log": "out/current-b2-official-baseline/install-official.log"}
    (ROOT / "validation/current-b2-baseline.json").write_text(json.dumps(record, indent=2) + "\n")
    print("Official recipe naming defect reproduced with b2 5.6.1.", flush=True)
else:
    raise SystemExit("Official recipe succeeded with current b2; reassess the diagnosis.")

case = {"id": "current-b2-clang-cl-1.91.0-debug-shared-versioned-minimal",
        "compiler": "clang-cl", "version": "1.91.0", "configuration": "Debug",
        "shared": True, "layout": "versioned", "selection": "minimal"}
passed = driver.validate(case)
if passed:
    graph = json.loads((ROOT / "out" / case["id"] / "graph.json").read_text())
    b2 = next(n for n in graph["graph"]["nodes"].values() if n.get("name") == "b2")
    if not b2["ref"].startswith("b2/5.6.1#"):
        raise SystemExit("Unexpected tool version in current-b2 smoke test.")
sys.exit(0 if passed else 1)
