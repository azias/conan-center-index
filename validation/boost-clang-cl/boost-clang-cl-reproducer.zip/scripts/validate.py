"""Run one approved Boost recipe validation matrix, with isolated OS-specific caches."""
import argparse
import datetime as dt
import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parents[1]
RECIPE = ROOT / "cci/recipes/boost/all"
SYSTEM = "windows" if os.name == "nt" else "linux"
ENV = os.environ.copy()
ENV["CONAN_HOME"] = os.environ.get("BOOST_RECIPE_CACHE", str(ROOT / ".conan-home" / SYSTEM))
if SYSTEM == "linux":
    ENV["PATH"] = str(ROOT / ".tools/linux/bin") + os.pathsep + ENV["PATH"]
CONAN = shutil.which("conan", path=ENV["PATH"])
CMAKE = shutil.which("cmake", path=ENV["PATH"])
CTEST = shutil.which("ctest", path=ENV["PATH"])
if not all([CONAN, CMAKE, CTEST]):
    raise SystemExit("Conan, CMake and CTest must be available.")
VS = ENV.get("BOOST_RECIPE_VS2022")
if SYSTEM == "windows" and (not VS or not ENV.get("VISUALSTUDIOVERSION", "").startswith("17.")):
    raise SystemExit("Initialize VS 2022 and set BOOST_RECIPE_VS2022 before running.")
SOURCE_CACHE = ROOT / "artifacts/source-cache"
EXPORTS = {}

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def run(args, directory, label, env=None):
    args = [str(a) for a in args]
    directory.mkdir(parents=True, exist_ok=True)
    log = directory / (label + ".log")
    if log.exists():
        history = directory / "history"
        history.mkdir(exist_ok=True)
        stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%S%f")
        shutil.copy2(log, history / (label + "-" + stamp + ".log"))
    with (directory / "commands.jsonl").open("a", encoding="utf-8") as f:
        f.write(json.dumps({"utc": now(), "cwd": str(ROOT), "argv": args}) + "\n")
    print(now(), "START", directory.name, label, flush=True)
    start = time.monotonic()
    with log.open("w", encoding="utf-8", errors="replace") as f:
        result = subprocess.run(args, cwd=ROOT, env=env or ENV,
                                stdout=f, stderr=subprocess.STDOUT)
    print(now(), "END", directory.name, label, result.returncode,
          round(time.monotonic() - start, 1), "s", flush=True)
    if result.returncode:
        tail = log.read_text(errors="replace")[-5000:]
        print(tail, flush=True)
        raise RuntimeError(f"{label} failed ({result.returncode}); see {log}")
    return log

def export(version):
    if version not in EXPORTS:
        directory = ROOT / "out" / ("export-" + SYSTEM + "-" + version)
        data = directory / "export.json"
        run([CONAN, "export", RECIPE, "--version=" + version,
             "--format=json", "--out-file=" + str(data)],
            directory, "export")
        exported = json.loads(data.read_text())
        # Conan 2.22 emits {"reference": "boost/...#rrev"}.
        reference = exported.get("reference")
        if not reference:
            match = re.search(r"boost/" + re.escape(version) + r"#[a-f0-9]{32}",
                              (directory / "export.log").read_text(errors="replace"))
            if not match:
                raise RuntimeError("Cannot determine exported recipe revision.")
            reference = match.group()
        EXPORTS[version] = reference
    return EXPORTS[version]

def profile_args(case):
    compiler = case["compiler"]
    build = "windows-msvc" if SYSTEM == "windows" else "linux-gcc"
    host = {"clang-cl": "windows-clang-cl", "msvc": "windows-msvc",
            "linux-gcc": "linux-gcc", "linux-clang": "linux-clang"}[compiler]
    args = ["-pr:b", ROOT / "profiles" / build,
            "-pr:h", ROOT / "profiles" / host,
            "-pr:h", ROOT / "profiles" / ("boost-" + case["selection"]),
            "-s:h", "build_type=" + case["configuration"],
            "-o:h", "boost/*:shared=" + str(case["shared"]),
            "-o:h", "boost/*:layout=" + case["layout"],
            "-o:h", "boost/*:debug_level=2",
            "-c:h", "tools.build:jobs=4",
            "-cc", "core.sources:download_cache=" + str(SOURCE_CACHE)]
    if case["compiler"] == "linux-clang":
        # Boost reads AR from buildenv, not compiler_executables (unlike CMake).
        args += ["-pr:h", ROOT / "followups/linux-tools/clang18-archiver"]
    if case["version"] == "1.91.0":
        # Upstream Test builds Regex implicitly; recipe metadata omits this dependency.
        args += ["-o:h", "boost/*:without_regex=False"]
    if SYSTEM == "windows":
        args += ["-s:h", "compiler.runtime_type=" + case["configuration"],
                 "-c:h", "tools.microsoft.msbuild:installation_path=" + VS,
                 "-c:b", "tools.microsoft.msbuild:installation_path=" + VS]
    return args

def fingerprint(case):
    h = hashlib.sha256(json.dumps(case, sort_keys=True).encode())
    for p in [RECIPE / "conanfile.py", *sorted((ROOT / "profiles").iterdir()),
              *sorted((ROOT / "reproducer").iterdir())]:
        if p.is_file():
            h.update(p.read_bytes())
    return h.hexdigest()

def audit_windows(case, package, directory):
    dumpbin = shutil.which("dumpbin.exe", path=ENV["PATH"])
    if not dumpbin:
        raise RuntimeError("VS 2022 dumpbin is missing.")
    monitor = list((package / "lib").glob("libboost_test_exec_monitor*.lib"))
    exception = list((package / "lib").glob("libboost_exception*.lib"))
    if not monitor or not exception:
        raise RuntimeError("Always-static component archives are missing.")
    directives = run([dumpbin, "/nologo", "/directives", exception[0]],
                     directory, "crt-directives")
    text = directives.read_text(errors="replace").lower()
    defaultlibs = {name.strip('"').removesuffix(".lib")
                   for name in re.findall(r'/defaultlib:("[^"]+"|\S+)', text)}
    expected = "msvcrtd" if case["configuration"] == "Debug" else "msvcrt"
    if expected not in defaultlibs:
        raise RuntimeError("Unexpected Microsoft CRT in exception archive: " + expected)
    json_dlls = list((package / "bin").glob("*boost_json*.dll"))
    if case["shared"]:
        if len(json_dlls) != 1:
            raise RuntimeError("Expected exactly one Boost.JSON DLL.")
        dependents = run([dumpbin, "/nologo", "/dependents", json_dlls[0]],
                         directory, "dll-dependents")
        text = dependents.read_text(errors="replace").lower()
        expected = "ucrtbased.dll" if case["configuration"] == "Debug" else "ucrtbase.dll"
        if expected not in text and not (case["configuration"] == "Release" and "api-ms-win-crt" in text):
            raise RuntimeError("Unexpected Microsoft CRT dependency: " + expected)
    elif json_dlls:
        raise RuntimeError("Static Boost package contains a JSON DLL.")
    return {"defaultlibs": sorted(defaultlibs),
            "static_archives": [p.name for p in monitor + exception],
            "json_dlls": [p.name for p in json_dlls]}

def validate(case):
    directory = ROOT / "out" / case["id"]
    directory.mkdir(parents=True, exist_ok=True)
    result_path = ROOT / "validation/results" / (case["id"] + ".json")
    result_path.parent.mkdir(parents=True, exist_ok=True)
    digest = fingerprint(case)
    if result_path.exists():
        old = json.loads(result_path.read_text())
        if old.get("status") == "passed" and old.get("fingerprint") == digest:
            print("REUSE verified result", case["id"], flush=True)
            return True
    result = {"case": case, "fingerprint": digest, "started": now(), "status": "running"}
    result_path.write_text(json.dumps(result, indent=2) + "\n")
    try:
        reference = export(case["version"])
        args = profile_args(case)
        graph = directory / "graph.json"
        # missing:boost/* permits rebuilding Boost only. Tools must be seeded beforehand.
        run([CONAN, "install", "--requires=" + reference, *args,
             "--build=missing:boost/*", "--no-remote",
             "-g", "CMakeDeps", "-g", "CMakeToolchain", "-g", "VirtualRunEnv",
             "-of", directory / "generators", "--format=json", "--out-file=" + str(graph)],
            directory, "install")
        nodes = json.loads(graph.read_text())["graph"]["nodes"].values()
        nodes = list(nodes)
        if any(n.get("name") not in (None, "boost", "b2") for n in nodes):
            raise RuntimeError("Unexpected dependency in isolated graph.")
        boost = next(n for n in nodes if n.get("name") == "boost")
        package = pathlib.Path(boost["package_folder"])
        result["package"] = {key: boost.get(key) for key in
                             ["ref", "rrev", "package_id", "prev", "package_folder", "settings", "options"]}
        result["libraries"] = sorted(p.name for p in (package / "lib").iterdir() if p.is_file())
        if SYSTEM == "windows":
            result["runtime_audit"] = audit_windows(case, package, directory)
        toolchain = directory / "generators/conan_toolchain.cmake"
        build = directory / "consumer"
        run([CMAKE, "-S", ROOT / "reproducer", "-B", build, "-G", "Ninja",
             "-DCMAKE_TOOLCHAIN_FILE=" + str(toolchain),
             "-DCMAKE_BUILD_TYPE=" + case["configuration"]],
            directory, "consumer-configure")
        run([CMAKE, "--build", build, "--parallel", "4", "--verbose"],
            directory, "consumer-build")
        test_env = ENV.copy()
        if SYSTEM == "windows":
            test_env["PATH"] = str(package / "bin") + os.pathsep + test_env["PATH"]
        else:
            test_env["LD_LIBRARY_PATH"] = str(package / "lib") + os.pathsep + test_env.get("LD_LIBRARY_PATH", "")
        run([CTEST, "--test-dir", build, "--output-on-failure"],
            directory, "consumer-test", test_env)
        run([CONAN, "test", RECIPE / "test_package", reference, *args,
             "--build=never", "--no-remote",
             "-c:h", "tools.cmake.cmake_layout:test_folder=" + str(directory / "official-test")],
            directory, "official-test-package")
        if SYSTEM == "linux":
            run(["ldd", build / "boost_json_consumer"], directory, "consumer-ldd", test_env)
        result["status"] = "passed"
    except Exception as error:
        result["status"] = "failed"
        result["error"] = str(error)
    result["finished"] = now()
    result_path.write_text(json.dumps(result, indent=2) + "\n")
    print("RESULT", case["id"], result["status"], result.get("error", ""), flush=True)
    return result["status"] == "passed"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", action="append", default=[])
    parser.add_argument("--all", action="store_true")
    args = parser.parse_args()
    cases = json.loads((ROOT / "validation/matrix.json").read_text())["cases"]
    selected = [c for c in cases if (SYSTEM == "linux") == c["compiler"].startswith("linux")]
    if not args.all:
        selected = [c for c in selected if c["id"] in args.case]
    if not selected:
        raise SystemExit("Select --case ID or --all (only this OS).")
    passed = [validate(c) for c in selected]
    print("SUMMARY", sum(passed), "/", len(passed), flush=True)
    return 0 if all(passed) else 1

if __name__ == "__main__":
    sys.exit(main())
