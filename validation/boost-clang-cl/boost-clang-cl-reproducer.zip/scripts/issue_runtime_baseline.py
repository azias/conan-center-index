"""Reproduce the static-CRT defect with the intact published recipe."""
import pathlib,sys,shutil,re,json
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
import validate as driver
reference='boost/1.91.0#857a04e51881582791677311c881b00d'
directory=driver.ROOT/'out/issue-runtime-official-static-crt'
driver.run([driver.CONAN,'download',reference,'--only-recipe','-r','conancenter'],directory,'download-official-recipe')
driver.export=lambda version: reference
original_profile_args=driver.profile_args
driver.profile_args=lambda case:original_profile_args(case)+['-s:h','compiler.runtime=static','-s:h','compiler.runtime_type=Release']
def audit(case,package,directory):
 dumpbin=shutil.which('dumpbin.exe',path=driver.ENV['PATH']); archive=next((package/'lib').glob('libboost_exception*.lib'))
 log=driver.run([dumpbin,'/nologo','/directives',archive],directory,'requested-crt-directives')
 text=log.read_text(errors='replace').lower(); libs={x.strip('"').removesuffix('.lib') for x in re.findall(r'/defaultlib:("[^"]+"|\S+)',text)}
 if 'msvcrt' in libs and 'libcmt' not in libs: raise RuntimeError('Official recipe ignored requested static CRT: archive uses MSVCRT instead of LIBCMT')
 raise RuntimeError('Expected official CRT mismatch was not observed: '+str(sorted(libs)))
driver.audit_windows=audit
case={'id':'issue-runtime-official-static-crt','compiler':'clang-cl','version':'1.91.0','configuration':'Release','shared':False,'layout':'system','selection':'minimal','runtime':'static','runtime_type':'Release'}
driver.validate(case)
record=json.loads((driver.ROOT/'validation/results/issue-runtime-official-static-crt.json').read_text())
reproduced=record.get('error','').startswith('Official recipe ignored requested static CRT:')
result={'status':'reproduced' if reproduced else 'unexpected-result','reference':reference,'qualified':False,'naming_patch_applied':False,'runtime_patch_applied':False,'package':record.get('package'),'error':record.get('error'),'log':'out/issue-runtime-official-static-crt/install.log'}
(driver.ROOT/'validation/additional/official-runtime-baseline.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key!='package'},indent=2),flush=True)
sys.exit(0 if reproduced else 1)
