"""Additional old-version probes; preserves the original 24-case matrix and profiles."""
import pathlib,sys,json
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
import validate as driver
cases=[
 {"id":"compat-clang-cl-1.78.0-debug-shared-versioned","compiler":"clang-cl","version":"1.78.0","configuration":"Debug","shared":True,"layout":"versioned","selection":"minimal"},
 {"id":"compat-clang-cl-1.78.0-release-static-versioned","compiler":"clang-cl","version":"1.78.0","configuration":"Release","shared":False,"layout":"versioned","selection":"minimal"},
 {"id":"compat-clang-cl-1.85.0-release-shared-tagged","compiler":"clang-cl","version":"1.85.0","configuration":"Release","shared":True,"layout":"tagged","selection":"minimal"},
]
if driver.SYSTEM!="windows": raise SystemExit("Initialize VS 2022 on Windows.")
(driver.ROOT/"validation/additional/legacy-matrix.json").write_text(json.dumps({"cases":cases},indent=2)+"\n")
original_profile_args=driver.profile_args
def profile_args(case):
    # Before 1.89, JSON's recipe metadata also requires Boost.System.
    return original_profile_args(case)+["-o:h","boost/*:without_system=False"]
driver.profile_args=profile_args
statuses=[{"id":case["id"],"passed":driver.validate(case)} for case in cases]
(driver.ROOT/"validation/additional/legacy-summary.json").write_text(json.dumps(statuses,indent=2)+"\n")
sys.exit(0 if all(x["passed"] for x in statuses) else 1)
