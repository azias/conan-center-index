"""Validate a Boost-scoped clang-cl profile with an MSVC consumer, reusing binaries."""
import pathlib
import json
import sys

import validate as driver

if driver.SYSTEM != "windows":
    raise SystemExit("Run in the VS 2022 environment.")
original_profile_args = driver.profile_args
original_run = driver.run
original_audit = driver.audit_windows

def profile_args(case):
    return original_profile_args(case) + [
        "-pr:h", driver.ROOT / "followups/scoped-profile/boost-clang-cl",
        "-s:h", "boost/*:compiler.runtime_type=" + case["configuration"]]

def run(args, *rest, **kwargs):
    # These probes must reuse the already-qualified clang-cl Boost binaries.
    args = ["--build=never" if str(x) == "--build=missing:boost/*" else x for x in args]
    return original_run(args, *rest, **kwargs)

def audit(case, package, directory):
    graph = json.loads((directory / "graph.json").read_text())
    boost = next(n for n in graph["graph"]["nodes"].values() if n.get("name") == "boost")
    if boost["settings"]["compiler"] != "clang":
        raise RuntimeError("Scoped profile did not select clang for Boost.")
    if boost["settings"]["compiler.runtime_type"] != case["configuration"]:
        raise RuntimeError("Scoped profile lost the requested Boost runtime_type.")
    result = original_audit(case, package, directory)
    result["boost_compiler"] = "clang"
    return result

driver.profile_args = profile_args
driver.run = run
driver.audit_windows = audit
passed = []
for config in ["Debug", "Release"]:
    for shared in [True, False]:
        case = {"id": "scoped-profile-msvc-consumer-clang-boost-1.89-" + config.lower()
                      + ("-shared" if shared else "-static"),
                "compiler": "msvc", "version": "1.89.0", "configuration": config,
                "shared": shared, "layout": "system", "selection": "minimal",
                "profile_mode": "MSVC consumer; Boost-only compiler=clang override"}
        ok = driver.validate(case)
        if ok:
            files = (driver.ROOT / "out" / case["id"] / "consumer/CMakeFiles").glob("*/CMakeCXXCompiler.cmake")
            actual_msvc = any('set(CMAKE_CXX_COMPILER_ID "MSVC")' in p.read_text() for p in files)
            if not actual_msvc:
                record_path = driver.ROOT / "validation/results" / (case["id"] + ".json")
                record = json.loads(record_path.read_text())
                record.update(status="failed", error="Consumer compiler is not MSVC.")
                record_path.write_text(json.dumps(record, indent=2) + "\n")
                ok = False
        passed.append(ok)
sys.exit(0 if all(passed) else 1)
