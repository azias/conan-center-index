"""Consume an already qualified combined-patch binary with a recent Conan client."""
import pathlib,os,sys,json,shutil,re,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1]
os.environ['BOOST_RECIPE_CACHE']=str(ROOT/'.conan-home/windows-conan-current')
sys.path.insert(0,str(ROOT/'scripts'))
import validate as driver
original_conan=driver.CONAN; current=ROOT/'.tools/conan-current/Scripts/conan.exe'
if not current.exists(): raise SystemExit('Prepare the isolated Conan 2.34.0 tool environment first.')
record=json.loads((ROOT/'validation/results/compat-runtime-1.78.0-release-static-static-crt-versioned.json').read_text()); assert record['status']=='passed'
p=record['package']; reference=p['ref']; full=reference+':'+p['package_id']+'#'+p['prev']; directory=ROOT/'out/current-conan-consumer-bootstrap'; archive=ROOT/'artifacts/current-conan-qualified-boost.tgz'
old_env=driver.ENV.copy(); old_env['CONAN_HOME']=str(ROOT/'.conan-home/windows')
driver.run([original_conan,'cache','save',full,'--file='+str(archive)],directory,'save-qualified-boost',old_env)
driver.CONAN=str(current); driver.RECIPE=ROOT/'followups/runtime/recipe'; driver.EXPORTS['1.78.0']=reference
driver.run([driver.CONAN,'cache','restore',archive],directory,'restore-qualified-boost')
driver.run([driver.CONAN,'cache','restore',ROOT/'artifacts/seed-b2-windows.tgz'],directory,'restore-b2')
original_profile_args=driver.profile_args
driver.profile_args=lambda case:original_profile_args(case)+['-o:h','boost/*:without_system=False','-s:h','compiler.runtime=static','-s:h','compiler.runtime_type=Release']
# No compilation of Boost or any dependency is permitted in this smoke check.
original_run=driver.run
def run(args,*rest,**kwargs):
 args=[str(a) for a in args]; args=['--build=never' if a=='--build=missing:boost/*' else a for a in args]
 return original_run(args,*rest,**kwargs)
driver.run=run
def audit(case,package,directory):
 tool=shutil.which('dumpbin.exe',path=driver.ENV['PATH']); archive=next((package/'lib').glob('libboost_exception*.lib'))
 log=driver.run([tool,'/nologo','/directives',archive],directory,'requested-crt-directives'); text=log.read_text(errors='replace').lower()
 libs={x.strip('"').removesuffix('.lib') for x in re.findall(r'/defaultlib:("[^"]+"|\S+)',text)}
 if 'libcmt' not in libs or 'msvcrt' in libs: raise RuntimeError('The restored binary does not have the qualified static CRT')
 return {'defaultlibs':sorted(libs),'requested':'static Release CRT'}
driver.audit_windows=audit
case={**record['case'],'id':'current-conan-runtime-1.78.0-release-static-static-crt-versioned','consumer_conan_version':'2.34.0'}
passed=driver.validate(case)
result={'status':'passed' if passed else 'failed','conan_version':subprocess.check_output([driver.CONAN,'--version'],text=True).strip(),'boost_rebuilt':False,'build_policy':'never','full_package_reference':full,'case_id':case['id'],'cache':'.conan-home/windows-conan-current'}
(ROOT/'validation/additional/current-conan-consumer.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2)); sys.exit(0 if passed else 1)
