"""Summarize actual results without treating unexecuted cases as successes."""
import collections
import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parents[1]
matrix = json.loads((ROOT / "validation/matrix.json").read_text())["cases"]
results = {}
for case in matrix:
    path = ROOT / "validation/results" / (case["id"] + ".json")
    record = json.loads(path.read_text()) if path.exists() else {"status": "not-run"}
    digest = hashlib.sha256(json.dumps(case, sort_keys=True).encode())
    for source in [ROOT / "cci/recipes/boost/all/conanfile.py",
                   *sorted((ROOT / "profiles").iterdir()),
                   *sorted((ROOT / "reproducer").iterdir())]:
        if source.is_file():
            digest.update(source.read_bytes())
    if record.get("status") in ("passed", "failed", "running") and record.get("fingerprint") != digest.hexdigest():
        record = {**record, "status": "superseded"}
    results[case["id"]] = record
counts = collections.Counter(r["status"] for r in results.values())
lines = [
    "# Boost clang-cl validation results", "",
    "Each row records execution, not an inference from another configuration.",
    "Maximum concurrency: one case, four build jobs.", "",
    "Components: JSON, Container, Exception and Test; Boost 1.91 also explicitly enables",
    "Regex because Test -> Algorithm -> Regex is not represented in recipe dependency data.",
    "Extended cases additionally enable Atomic, Chrono, DateTime, Filesystem, Regex,",
    "Serialization and Thread. No claim is made that every Boost module was compiled.", "",
    "| Compiler | Boost | Build | Link | Layout | Selection | Status |",
    "| --- | --- | --- | --- | --- | --- | --- |"
]
summary = []
for case in matrix:
    result = results[case["id"]]
    status = result["status"]
    if status == "passed":
        package = result["package"]
        ref = package["ref"] + ":" + package["package_id"] + "#" + str(package["prev"])
    else:
        ref = None
    row = {**case, "status": status, "full_package_reference": ref,
           "libraries": result.get("libraries", []),
           "error": result.get("error")}
    summary.append(row)
    lines.append("| {compiler} | {version} | {configuration} | {link} | {layout} | {selection} | {status} |".format(
        **{**case, "link": "shared" if case["shared"] else "static", "status": status}))
lines += ["", "Counts: " + ", ".join(f"{k}={v}" for k, v in sorted(counts.items())), "",
          "## Acceptance performed for successful rows", "",
          "- Conan installation and package_info completed without missing/unused-library errors.",
          "- The CMake JSON round-trip and always-static-component consumers built and ran.",
          "- The upstream recipe test_package built and ran.",
          "- Windows archive directives and JSON DLL dependencies match the requested dynamic CRT.",
          "- Linux consumers were also inspected with ldd.",
          "- Exact argument arrays, profiles, graph and detailed logs are retained under out/<case>/.", "",
          "## Independent findings", "",
          "- The official 1.89 baseline was reproduced without Platypus dependencies.",
          "- clang-cl ignores -fPIC and -stdlib=None; lld-link also ignores the latter.",
          "  They did not cause the demonstrated package_info failure and remain outside the naming diff.",
          "- VS 2022 headers were confirmed in actual object CodeView records, rather than inferred",
          "  from discovery messages. Selected components do not qualify every assembler/Context path.",
          "- Boost 1.91's implicit Regex dependency is tracked separately as CCI issue #31040.",
          "- The static/shared naming patch and the Microsoft CRT follow-up remain separate.", "",
          "## Limits", "",
          "MSVC and Linux regression rows use Release. The required clang-cl system-layout rows",
          "cover both Debug and Release. Only the listed configurations were compiled; the 1.90",
          "intermediate-version check is a single Release/shared case. MinGW, legacy",
          "compiler=msvc/toolset=ClangCL, other architectures and all optional Boost modules",
          "are not qualified by this matrix.", ""]
probes = {}
for path in sorted((ROOT / "validation/results").glob("probe-runtime-*.json")):
    record = json.loads(path.read_text())
    probes[path.stem] = {"status": record["status"], "error": record.get("error"),
                        "package": {key: value for key, value in record.get("package", {}).items()
                                    if key != "package_folder"}}
public = {"counts": dict(counts), "cases": summary, "runtime_probes": probes,
          "naming_recipe_sha256": hashlib.sha256((ROOT / "cci/recipes/boost/all/conanfile.py").read_bytes()).hexdigest(),
          "complete": counts.get("passed", 0) == len(matrix)}
public["scoped_profile_probes"] = {}
for path in sorted((ROOT / "validation/results").glob("scoped-profile-*.json")):
    item = json.loads(path.read_text())
    public["scoped_profile_probes"][path.stem] = {"status": item["status"]}
current = ROOT / "validation/results/current-b2-clang-cl-1.91.0-debug-shared-versioned-minimal.json"
original = ROOT / "validation/current-b2-baseline.json"
public["current_b2_smoke"] = {"status": json.loads(current.read_text())["status"] if current.exists() else "not-run",
                              "official_baseline": json.loads(original.read_text())["status"] if original.exists() else "not-run"}
public["all_validation_complete"] = (public["complete"]
    and public["current_b2_smoke"]["status"] == "passed"
    and public["current_b2_smoke"]["official_baseline"] == "reproduced"
    and len(public["scoped_profile_probes"]) == 4
    and all(x["status"] == "passed" for x in public["scoped_profile_probes"].values())
    and len([x for key, x in probes.items() if key.startswith("probe-runtime-fixed-") and x["status"] == "passed"]) == 2)
lines += ["## Additional executed checks", "",
          "Current b2 smoke: " + public["current_b2_smoke"]["status"] + "; official failure: " + public["current_b2_smoke"]["official_baseline"] + ".",
          "Four MSVC-consumer/clang-cl-Boost profile probes reuse binaries with --build=never.",
          "Two original CRT mismatches and two successful separate runtime-follow-up cases are recorded separately.",
          "The follow-up rejects shared/static-CRT before compilation.", "",
          "The main Windows matrix uses the dynamic CRT with runtime_type matching build_type.",
          "The combined runtime-follow-up recipe did not run the entire main matrix.", ""]
(ROOT / "validation/summary.json").write_text(json.dumps(public, indent=2) + "\n")
(ROOT / "validation/results.md").write_text("\n".join(lines), encoding="utf-8")
patch = subprocess.check_output(["git", "-C", str(ROOT / "cci"), "diff", "--binary", "--",
                                 "recipes/boost/all/conanfile.py"])
(ROOT / "artifacts/boost-clang-cl-naming.patch").write_bytes(patch)
print(json.dumps({"counts": dict(counts), "complete": public["complete"]}))
