[CmdletBinding()]
param([switch]$Execute)
$ErrorActionPreference = 'Stop'
$workRoot = Split-Path -Parent $PSScriptRoot
$manifest = Get-Content -Raw -LiteralPath (Join-Path $workRoot 'manifest.json') | ConvertFrom-Json
$conanHome = Join-Path $workRoot '.conan-home\windows'
$reference = 'boost/1.89.0#' + $manifest.baseline_revisions.'1.89.0'
$arguments = @(
    'install', "--requires=$reference",
    '-pr:b', '.\profiles\windows-msvc',
    '-pr:h', '.\profiles\windows-clang-cl',
    '-pr:h', '.\profiles\boost-minimal',
    '-s:h', 'build_type=Debug', '-s:h', 'compiler.runtime_type=Debug',
    '-o:h', 'boost/*:shared=True', '-o:h', 'boost/*:layout=system',
    '-o:h', 'boost/*:debug_level=2', '-c:h', 'tools.build:jobs=4',
    '--build=boost/*', '--no-remote',
    '-g', 'CMakeDeps', '-g', 'CMakeToolchain', '-g', 'VirtualRunEnv',
    '-of', '.\out\baseline-1.89-debug-shared'
)
Write-Output 'Purpose: reproduce the official unmodified recipe in an isolated cache.'
Write-Output 'May rebuild: Boost 1.89.0 only. b2 must already be imported. No Conan remote access; source HTTP download is possible.'
Write-Output 'VS 2022 will be discovered with vswhere and passed to both Conan contexts.'
Write-Output '$env:CONAN_HOME = Join-Path $workRoot ".conan-home\windows"'
$preview = ($arguments | ForEach-Object { "'" + $_.Replace("'", "''") + "'" }) -join ' '
Write-Output ('conan ' + $preview + ' -c:h "tools.microsoft.msbuild:installation_path=$vs2022" -c:b "tools.microsoft.msbuild:installation_path=$vs2022"')
if (-not $Execute) { return }
if (-not (Test-Path -LiteralPath (Join-Path $conanHome 'p\cache.sqlite3'))) { throw 'Prepare the isolated cache first.' }
Push-Location $workRoot
$previousHome = $env:CONAN_HOME
try {
    $vs = & (Join-Path $PSScriptRoot 'Initialize-VS2022.ps1')
    $vs2022 = $vs.InstallationPath
    if (-not $vs2022) { throw 'VS discovery did not return an installation path.' }
    $env:CONAN_HOME = $conanHome
    $arguments += @('-c:h', "tools.microsoft.msbuild:installation_path=$vs2022", '-c:b', "tools.microsoft.msbuild:installation_path=$vs2022")
    $log = Join-Path $workRoot 'logs\baseline-1.89-debug-shared.log'
    & conan @arguments 2>&1 | Tee-Object -FilePath $log | Out-Null
    $result = $LASTEXITCODE
    if ($result -ne 0) { throw "Baseline exited with code $result. See $log" }
} finally {
    $env:CONAN_HOME = $previousHome
    Pop-Location
}
