"""Compare official/patched Boost under isolated MSYS2 toolchains, with real consumers."""
import argparse,json,pathlib,sys,os,subprocess,shutil,re,hashlib
ROOT=pathlib.Path(__file__).resolve().parents[1]
os.environ['BOOST_RECIPE_CACHE']=str(ROOT/'.conan-home/msys2')
sys.path.insert(0,str(ROOT/'scripts'))
import validate as driver
parser=argparse.ArgumentParser(); parser.add_argument('--compiler',choices=['clang64','ucrt64'],required=True); parser.add_argument('--stage',choices=['official','naming','runtime'],default='naming'); parser.add_argument('--prepare-only',action='store_true'); args=parser.parse_args()
msys=ROOT/'.tools/msys2-validation/msys64'; prefix=msys/args.compiler/'bin'
cpp=prefix/('clang++.exe' if args.compiler=='clang64' else 'g++.exe')
if not cpp.exists(): raise SystemExit('Bootstrap the dedicated MSYS2 root first.')
# Retain the initialized VS 2022 environment for the separate MSVC build context.
driver.ENV['PATH']=str(prefix)+os.pathsep+driver.ENV['PATH']
version=subprocess.check_output([str(cpp),'--version'],env=driver.ENV,text=True,encoding='utf-8').splitlines()[0]
major=re.search(r'(?:version |\) )(\d+)\.',version).group(1)
actual_target=subprocess.check_output([str(cpp),'-dumpmachine'],env=driver.ENV,text=True).strip()
compiler='clang' if args.compiler=='clang64' else 'gcc'; libcxx='libc++' if compiler=='clang' else 'libstdc++11'
work=ROOT/'followups/msys2'; work.mkdir(exist_ok=True); profiles=work/'profiles'; profiles.mkdir(exist_ok=True)
profile=profiles/args.compiler
profile.write_text('[settings]\nos=Windows\narch=x86_64\nbuild_type=Release\ncompiler='+compiler+'\ncompiler.version='+major+'\ncompiler.cppstd=17\ncompiler.libcxx='+libcxx+'\n\n[conf]\ntools.build:compiler_executables='+json.dumps({'c':'clang.exe' if compiler=='clang' else 'gcc.exe','cpp':cpp.name})+'\ntools.cmake.cmaketoolchain:generator=Ninja\ntools.build:jobs=4\n\n[buildenv]\nAR='+('llvm-ar.exe' if compiler=='clang' else 'ar.exe')+'\n',encoding='utf-8',newline='\n')
bootstrap=ROOT/'out/msys2-conan-bootstrap'
config=work/'config'; config.mkdir(exist_ok=True)
(config/'settings_user.yml').write_text('compiler:\n  gcc:\n    version: ["16"]\n  clang:\n    version: ["23"]\n',encoding='utf-8',newline='\n')
driver.run([driver.CONAN,'config','install',config],bootstrap,'settings-user')
pkgid='522dcea5982a3f8a5b624c16477e47195da2f84f'
listed=subprocess.run([driver.CONAN,'list','b2/5.5.3#043a75bcbb090e3f81f7ac849850d0ca:'+pkgid,'--format=json'],env=driver.ENV,capture_output=True,text=True,check=True)
if pkgid not in listed.stdout: driver.run([driver.CONAN,'cache','restore',ROOT/'artifacts/seed-b2-windows.tgz'],bootstrap,'restore-b2')
if args.stage=='official':
 recipe=work/'official'
 if not recipe.exists(): shutil.copytree(ROOT/'cci/recipes/boost/all',recipe,ignore=shutil.ignore_patterns('__pycache__'))
 (recipe/'conanfile.py').write_bytes(subprocess.check_output(['git','-C',str(ROOT/'cci'),'show','HEAD:recipes/boost/all/conanfile.py']))
 driver.RECIPE=recipe
elif args.stage=='runtime': driver.RECIPE=ROOT/'followups/runtime/recipe'

def profile_args(case):
 return ['-pr:b',ROOT/'profiles/windows-msvc','-pr:h',profile,'-pr:h',ROOT/'profiles/boost-minimal','-s:h','build_type=Release','-o:h','boost/*:shared=True','-o:h','boost/*:layout=system','-o:h','boost/*:debug_level=2','-c:h','tools.build:jobs=4','-c:b','tools.microsoft.msbuild:installation_path='+driver.VS,'-c:h','tools.microsoft.msbuild:installation_path='+driver.VS,'-cc','core.sources:download_cache='+str(driver.SOURCE_CACHE)]
driver.profile_args=profile_args

def audit(case,package,directory):
 dlls=list((package/'bin').glob('*boost_json*.dll')); exceptions=list((package/'lib').glob('*boost_exception*.a')); monitors=list((package/'lib').glob('*boost_test_exec_monitor*.a'))
 if len(dlls)!=1 or not exceptions or not monitors: raise RuntimeError('Expected MSYS2 DLL and always-static archives are missing')
 dumpbin=shutil.which('dumpbin.exe',path=driver.ENV['PATH'])
 log=driver.run([dumpbin,'/nologo','/dependents',dlls[0]],directory,'mingw-dll-dependents')
 return {'json_dlls':[p.name for p in dlls],'always_static':[p.name for p in exceptions+monitors],'dll_dependencies_log':str(log.relative_to(ROOT)),'microsoft_crt_flags_applicable':False}
driver.audit_windows=audit
case={'id':'msys2-'+args.compiler+'-'+args.stage+'-1.89.0-release-shared-system','compiler':'msys2-'+compiler,'version':'1.89.0','configuration':'Release','shared':True,'layout':'system','selection':'minimal','actual_compiler':compiler,'compiler_version':major,'target':actual_target}
if args.prepare_only:
 print(json.dumps({'prepared':True,'compiler':version,'target':actual_target,'profile':str(profile.relative_to(ROOT))},indent=2)); sys.exit(0)
passed=driver.validate(case)
record=json.loads((ROOT/'validation/results'/(case['id']+'.json')).read_text())
log=(ROOT/'out'/case['id']/'install.log').read_text(errors='replace')
errors=[line.strip() for line in log.splitlines() if re.search(r'error:|cannot|not found|toolset=clang-win|runtime-debugging=|runtime-link=',line,re.I)]
result={'case':case,'status':record['status'],'compiler_banner':version,'target':actual_target,'stage':args.stage,'recipe_sha256':hashlib.sha256((driver.RECIPE/'conanfile.py').read_bytes()).hexdigest(),'error':record.get('error'),'relevant_log_lines':errors[:35]}
(ROOT/'validation/additional'/(case['id']+'.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2),flush=True)
sys.exit(0 if passed else 1)
