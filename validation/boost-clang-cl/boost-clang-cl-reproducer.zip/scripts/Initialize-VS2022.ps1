[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$programFilesX86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
$vswhere = Join-Path $programFilesX86 'Microsoft Visual Studio\Installer\vswhere.exe'
if (-not (Test-Path -LiteralPath $vswhere)) { throw 'vswhere.exe is not installed.' }
$vs2022 = & $vswhere -version '[17.0,18.0)' -products '*' -latest -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
if ($LASTEXITCODE -ne 0 -or -not $vs2022) { throw 'Visual Studio 2022 C++ tools were not found.' }
& (Join-Path $vs2022 'Common7\Tools\Launch-VsDevShell.ps1') -Arch amd64 -HostArch amd64 -SkipAutomaticLocation
if ($env:VisualStudioVersion -notlike '17.*') { throw 'Expected a Visual Studio 2022 environment.' }
$tools = (Resolve-Path -LiteralPath $env:VCToolsInstallDir).Path.TrimEnd('\')
$compiler = (Get-Command cl.exe -ErrorAction Stop).Source
$linker = (Get-Command link.exe -ErrorAction Stop).Source
if (-not $compiler.StartsWith($tools, [StringComparison]::OrdinalIgnoreCase)) { throw 'cl.exe is outside the selected VS tools directory.' }
if (-not $linker.StartsWith($tools, [StringComparison]::OrdinalIgnoreCase)) { throw 'link.exe is outside the selected VS tools directory.' }
[pscustomobject]@{
    InstallationPath = $vs2022
    Toolset = $env:VCToolsVersion
    Compiler = $compiler
    Linker = $linker
    ClangCl = (Get-Command clang-cl.exe -ErrorAction Stop).Source
    WindowsSDK = $env:WindowsSDKVersion
}
