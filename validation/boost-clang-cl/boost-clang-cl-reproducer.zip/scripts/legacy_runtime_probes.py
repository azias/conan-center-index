"""Check the independent runtime patch at the oldest supported Boost version."""
import pathlib,sys,shutil,re,json
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
import validate as driver
if driver.SYSTEM!='windows': raise SystemExit('Initialize VS 2022 on Windows.')
driver.RECIPE=driver.ROOT/'followups/runtime/recipe'
original_profile_args=driver.profile_args
def profiles(case):
 return original_profile_args(case)+['-o:h','boost/*:without_system=False','-s:h','compiler.runtime='+case['runtime'],'-s:h','compiler.runtime_type='+case['runtime_type']]
driver.profile_args=profiles
def audit(case,package,directory):
 dumpbin=shutil.which('dumpbin.exe',path=driver.ENV['PATH']); exception=next((package/'lib').glob('libboost_exception*.lib'))
 log=driver.run([dumpbin,'/nologo','/directives',exception],directory,'requested-crt-directives')
 text=log.read_text(errors='replace').lower(); libs={x.strip('"').removesuffix('.lib') for x in re.findall(r'/defaultlib:("[^"]+"|\S+)',text)}
 expected=('libcmt' if case['runtime']=='static' else 'msvcrt')+('d' if case['runtime_type']=='Debug' else '')
 if expected not in libs: raise RuntimeError('Wrong CRT default library; expected '+expected)
 dlls=list((package/'bin').glob('*boost_json*.dll'))
 if case['shared']:
  log=driver.run([dumpbin,'/nologo','/dependents',dlls[0]],directory,'requested-crt-dll'); text=log.read_text(errors='replace').lower()
  if case['runtime_type']=='Release' and ('ucrtbased.dll' in text or not ('ucrtbase.dll' in text or 'api-ms-win-crt' in text)): raise RuntimeError('Wrong Release CRT DLL dependencies')
 return {'requested_runtime':case['runtime'],'runtime_type':case['runtime_type'],'archive_defaultlibs':sorted(libs),'expected':expected,'json_dlls':[p.name for p in dlls]}
driver.audit_windows=audit
cases=[
 {'id':'compat-runtime-1.78.0-debug-shared-release-crt-tagged','compiler':'clang-cl','version':'1.78.0','configuration':'Debug','shared':True,'layout':'tagged','selection':'minimal','runtime':'dynamic','runtime_type':'Release'},
 {'id':'compat-runtime-1.78.0-release-static-static-crt-versioned','compiler':'clang-cl','version':'1.78.0','configuration':'Release','shared':False,'layout':'versioned','selection':'minimal','runtime':'static','runtime_type':'Release'}]
(driver.ROOT/'validation/additional/legacy-runtime-matrix.json').write_text(json.dumps({'cases':cases},indent=2)+'\n')
statuses=[{'id':case['id'],'passed':driver.validate(case)} for case in cases]
(driver.ROOT/'validation/additional/legacy-runtime-summary.json').write_text(json.dumps(statuses,indent=2)+'\n')
sys.exit(0 if all(x['passed'] for x in statuses) else 1)
