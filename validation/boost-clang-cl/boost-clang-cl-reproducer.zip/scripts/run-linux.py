"""Portable Linux bootstrap/runner; keeps system packages and the usual cache untouched."""
import argparse
import json
import os
import pathlib
import shutil
import subprocess
import sys
import venv

if os.name == "nt":
    raise SystemExit("Run this script with Linux Python, for example inside WSL.")
ROOT = pathlib.Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--setup-only", action="store_true")
parser.add_argument("--case", action="append", default=[])
parser.add_argument("--all", action="store_true")
args = parser.parse_args()
cache = pathlib.Path(os.environ.get("BOOST_RECIPE_CACHE",
                                   pathlib.Path.home() / ".cache/conan-boost-clang-cl"))
marker = cache / "investigation.json"
if cache.exists() and not marker.exists():
    raise SystemExit("Refusing to reuse an unrecognized cache directory: " + str(cache))
cache.mkdir(parents=True, exist_ok=True)
marker.write_text(json.dumps({"cci_commit": "db8236fe4e9018dbd1b72ff970def9708e8907d4",
                              "purpose": "isolated Boost recipe validation"}, indent=2) + "\n")
tools = ROOT / ".tools/linux"
if not (tools / "bin/python").exists():
    venv.EnvBuilder(with_pip=True).create(tools)
if not (tools / "bin/cmake").exists():
    subprocess.run([str(tools / "bin/python"), "-m", "pip", "install", "cmake==4.2.3"], check=True)
if not shutil.which("ninja"):
    raise SystemExit("Install/provide Ninja in your Linux environment before running.")
env = os.environ.copy()
env["CONAN_HOME"] = str(cache)
env["BOOST_RECIPE_CACHE"] = str(cache)
env["PATH"] = str(tools / "bin") + os.pathsep + env["PATH"]
reference = "b2/5.5.3#043a75bcbb090e3f81f7ac849850d0ca"
pkgid = "63fead0844576fc02943e16909f08fcdddd6f44b"
listed = subprocess.run(["conan", "list", reference + ":" + pkgid, "--format=json"],
                        env=env, capture_output=True, text=True, check=True)
def has_package(node):
    if isinstance(node, dict):
        return pkgid in node.get("packages", {}) or any(has_package(v) for v in node.values())
    if isinstance(node, list):
        return any(has_package(v) for v in node)
    return False
if not has_package(json.loads(listed.stdout)):
    archive = ROOT / "artifacts/seed-b2-linux.tgz"
    if archive.exists():
        subprocess.run(["conan", "cache", "restore", str(archive)], env=env, check=True)
    else:
        official = reference + ":" + pkgid + "#2df3961323f7385a6bb9d97e974d8faa"
        subprocess.run(["conan", "download", official, "-r", "conancenter"], env=env, check=True)
print("Prepared isolated Linux cache:", cache, flush=True)
if args.setup_only:
    sys.exit(0)
if not args.all and not args.case:
    raise SystemExit("Select --all or --case ID; bootstrap completed without compiling.")
command = [sys.executable, "-u", "-B", str(ROOT / "scripts/validate.py")]
command += ["--all"] if args.all else [x for value in args.case for x in ("--case", value)]
sys.exit(subprocess.run(command, env=env, cwd=ROOT).returncode)
