import pathlib,json,yaml,hashlib,datetime
root=pathlib.Path.cwd(); recipe=root/'cci/recipes/boost/all'; versions=yaml.safe_load((recipe.parent/'config.yml').read_text())['versions']; rows=[]
for v in versions:
 dpath=recipe/'dependencies'/('dependencies-'+v+'.yml'); data=yaml.safe_load(dpath.read_text()); static=data['static_only']
 assert set(static)=={'boost_exception','boost_test_exec_monitor'},(v,static)
 assert str(data['version'])==v,(v,data['version'])
 rows.append({'version':v,'recipe_folder':versions[v]['folder'],'static_only':static,'json_dependencies':data['dependencies'].get('json',[]),'dependency_metadata_sha256':hashlib.sha256(dpath.read_bytes()).hexdigest()})
record={'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Metadata consistency across all supported versions; does not claim compilation of each version.','versions':rows}
(root/'validation/additional/version-metadata.json').write_text(json.dumps(record,indent=2)+'\n'); print(json.dumps([{'version':x['version'],'static_only':x['static_only'],'json_dependencies':x['json_dependencies']} for x in rows],indent=2))
