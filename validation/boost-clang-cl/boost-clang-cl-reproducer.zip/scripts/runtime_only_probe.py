"""Validate the exact runtime PR branch without the naming correction."""
import pathlib,sys,json,shutil,re,subprocess
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import validate as driver
recipe=ROOT/'followups/runtime-only/recipe'
if not recipe.exists(): shutil.copytree(ROOT/'cci/recipes/boost/all',recipe,ignore=shutil.ignore_patterns('__pycache__'))
state_file=ROOT/'publication/state.json'
sha=json.loads(state_file.read_text())['branches']['pr2']['commit'] if state_file.exists() else '6a60d75b0b5e7d84a8f81a1ae7e596b56e3d33e2'
check=subprocess.run(['git','-C',str(ROOT/'cci'),'cat-file','-e',sha+'^{commit}'],capture_output=True)
if check.returncode:
 subprocess.run(['git','-C',str(ROOT/'cci'),'fetch','--no-tags','https://github.com/azias/conan-center-index.git',sha],check=True)
(recipe/'conanfile.py').write_bytes(subprocess.check_output(['git','-C',str(ROOT/'cci'),'show',sha+':recipes/boost/all/conanfile.py']))
driver.RECIPE=recipe
old_profiles=driver.profile_args
driver.profile_args=lambda case:old_profiles(case)+['-s:h','compiler.runtime=static','-s:h','compiler.runtime_type=Release']
def audit(case,package,directory):
 tool=shutil.which('dumpbin.exe',path=driver.ENV['PATH']); archive=next((package/'lib').glob('libboost_exception*.lib'))
 log=driver.run([tool,'/nologo','/directives',archive],directory,'requested-crt-directives'); text=log.read_text(errors='replace').lower()
 libs={x.strip('"').removesuffix('.lib') for x in re.findall(r'/defaultlib:("[^"]+"|\S+)',text)}
 if 'libcmt' not in libs or 'msvcrt' in libs: raise RuntimeError('Standalone runtime patch did not produce static CRT objects')
 return {'expected':'libcmt','defaultlibs':sorted(libs),'naming_patch_applied':False}
driver.audit_windows=audit
case={'id':'runtime-only-1.91.0-release-static-static-crt-system','compiler':'clang-cl','version':'1.91.0','configuration':'Release','shared':False,'layout':'system','selection':'minimal','runtime':'static','runtime_type':'Release','naming_patch_applied':False,'pr_commit':sha}
passed=driver.validate(case)
result={'status':'passed' if passed else 'failed','case':case,'naming_patch_applied':False,'recipe_source':'exact PR 31349 branch','pr_commit':sha,'qualified':passed,'log':'out/'+case['id']+'/install.log'}
(ROOT/'validation/additional/runtime-only.json').write_text(json.dumps(result,indent=2)+'\n'); print(json.dumps(result,indent=2)); sys.exit(0 if passed else 1)
