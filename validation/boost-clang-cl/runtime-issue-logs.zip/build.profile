[settings]
os=Windows
arch=x86_64
build_type=Release
compiler=msvc
compiler.version=194
compiler.cppstd=17
compiler.runtime=dynamic
compiler.runtime_type=Release

[conf]
tools.cmake.cmaketoolchain:generator=Ninja
tools.build:jobs=4
